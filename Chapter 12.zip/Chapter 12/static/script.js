document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('pdfForm');
    const output = document.getElementById('output');
    const feedback = document.getElementById('feedback');
    const loading = document.getElementById('loading');
    const downloadButton = document.getElementById('downloadButton');
    const darkModeToggle = document.getElementById('darkModeToggle');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const searchText = document.getElementById('sText');
    const replaceText = document.getElementById('rText');
    const caseSensitive = document.getElementById('caseSensitive');
    let originalPdfText = '';
    let processedPdfData = null;

    // Handle form submission
    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        clearMessages();
        showLoading();

        // Validate form inputs
        if (!validateForm()) {
            showFeedback('Please fill in all required fields.', 'error');
            hideLoading();
            return;
        }

        const formData = new FormData(form);
        try {
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();

            if (data.error) {
                showFeedback(data.error, 'error');
            } else {
                originalPdfText = data.original_text;
                updatePdfContent();
                showFeedback('Text replaced successfully! You can download the processed PDF below.', 'success');
                processedPdfData = data.processed_pdf;
                downloadButton.style.display = 'block';
            }
        } catch (error) {
            showFeedback(`Error: ${error.message}`, 'error');
        } finally {
            hideLoading();
        }
    });

    // Handle download button click
    downloadButton.addEventListener('click', () => {
        if (processedPdfData) {
            const blob = new Blob([new Uint8Array(processedPdfData.match(/.{1,2}/g).map(byte => parseInt(byte, 16)))], { type: 'application/pdf' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'processed.pdf';
            link.click();
        }
    });

    // Handle dark mode toggle switch
    darkModeToggle.addEventListener('change', () => {
        document.body.classList.toggle('dark-mode', darkModeToggle.checked);
    });

    // Handle input changes for real-time search and replace
    searchText.addEventListener('input', updatePdfContent);
    replaceText.addEventListener('input', updatePdfContent);
    caseSensitive.addEventListener('change', updatePdfContent);

    // Clear messages
    function clearMessages() {
        output.textContent = '';
        feedback.textContent = '';
        downloadButton.style.display = 'none';
    }

    // Show loading spinner
    function showLoading() {
        loading.style.display = 'block';
    }

    // Hide loading spinner
    function hideLoading() {
        loading.style.display = 'none';
    }

    // Display feedback message
    function showFeedback(message, type) {
        feedback.textContent = message;
        feedback.className = type;
    }

    // Validate form inputs
    function validateForm() {
        return searchText.value.trim() !== '' &&
               replaceText.value.trim() !== '' &&
               form.pdfFile.files.length > 0;
    }

    // Handle file input change
    document.getElementById('pdfFile').addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file && file.type === 'application/pdf') {
            fileNameDisplay.textContent = `Selected file: ${file.name}`;
            const reader = new FileReader();
            reader.onload = function(e) {
                const pdfData = e.target.result;
                displayPDFContent(pdfData);
            };
            reader.readAsArrayBuffer(file);
        } else {
            fileNameDisplay.textContent = 'Please upload a PDF document.';
        }
    });

    // Display the text content of the uploaded PDF
    function displayPDFContent(pdfData) {
        const loadingTask = pdfjsLib.getDocument({ data: pdfData });
        loadingTask.promise.then(pdf => {
            let pdfText = '';
            const numPages = pdf.numPages;
            const pageTextPromises = [];

            for (let pageNum = 1; pageNum <= numPages; pageNum++) {
                pageTextPromises.push(pdf.getPage(pageNum).then(page => {
                    return page.getTextContent().then(textContent => {
                        return textContent.items.map(item => item.str).join(' ');
                    });
                }));
            }

            Promise.all(pageTextPromises).then(pagesText => {
                originalPdfText = pagesText.join('\n\n');
                updatePdfContent();
            });
        }, reason => {
            console.error(reason);
        });
    }

    // Update the displayed PDF content based on search and replace inputs
    function updatePdfContent() {
        if (!originalPdfText) return;

        let searchValue = searchText.value;
        let replaceValue = replaceText.value;
        let flags = caseSensitive.checked ? 'g' : 'gi';

        try {
            let regex = new RegExp(searchValue, flags);
            let newText = originalPdfText.replace(regex, replaceValue);
            output.textContent = newText;
        } catch (e) {
            console.error(e);
        }
    }
});
