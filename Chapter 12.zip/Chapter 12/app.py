from flask import Flask, request, jsonify, render_template, send_file
import pdfplumber
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import io
import re
import logging

app = Flask(__name__)

logging.basicConfig(level=logging.DEBUG)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    logging.debug('Received upload request')
    file = request.files.get('file')
    search_text = request.form.get('search_text')
    replace_text = request.form.get('replace_text')
    case_sensitive = request.form.get('case_sensitive') == 'true'

    if not file or not file.filename.endswith('.pdf'):
        return jsonify({'error': 'Invalid file format. Please upload a PDF file.'}), 400

    if not search_text or not replace_text:
        return jsonify({'error': 'Search and replace text cannot be empty.'}), 400

    try:
        with pdfplumber.open(file) as pdf:
            pages = extract_and_replace_text(pdf, search_text, replace_text, case_sensitive)
        processed_pdf = create_pdf(pages)
        return jsonify({
            'original_text': ''.join(page['text'] for page in pages),
            'processed_pdf': processed_pdf.getvalue().hex()
        })
    except Exception as e:
        logging.error(f'Error processing PDF: {e}')
        return jsonify({'error': f'Error processing PDF: {str(e)}'}), 500

@app.route('/download', methods=['POST'])
def download_pdf():
    data = request.get_json()
    processed_pdf_bytes = bytes.fromhex(data['processed_pdf'])
    output_buffer = io.BytesIO(processed_pdf_bytes)
    output_buffer.seek(0)
    return send_file(output_buffer, download_name='output.pdf', as_attachment=True)

def extract_and_replace_text(pdf, search_text, replace_text, case_sensitive):
    pages = []
    flags = re.IGNORECASE if not case_sensitive else 0
    for page in pdf.pages:
        text_objs = []
        for obj in page.extract_words(use_text_flow=True, keep_blank_chars=True):
            text = re.sub(re.escape(search_text), replace_text, obj['text'], flags=flags)
            text_objs.append({
                'text': text,
                'x0': obj['x0'],
                'top': obj['top'],
                'x1': obj['x1'],
                'bottom': obj['bottom'],
                'doctop': obj['doctop'],
                'fontname': obj.get('fontname', 'Helvetica'),
                'size': obj.get('size', 12)
            })
        pages.append({'text': ' '.join(obj['text'] for obj in text_objs), 'objects': text_objs})
    return pages

def create_pdf(pages):
    output_buffer = io.BytesIO()
    c = canvas.Canvas(output_buffer, pagesize=letter)
    for page in pages:
        for obj in page['objects']:
            x = obj['x0']
            y = letter[1] - obj['top']  # Adjust y-coordinate based on the page height
            fontname = obj['fontname']
            fontsize = obj['size']
            try:
                c.setFont(fontname, fontsize)
            except:
                c.setFont('Helvetica', fontsize)  # Fallback to default font if custom font not available
            c.drawString(x, y, obj['text'])
        c.showPage()
    c.save()
    output_buffer.seek(0)
    return output_buffer

if __name__ == '__main__':
    app.run(debug=True)
