function runCallbackExample() {
    function fetchDataCallback(callback) {
        setTimeout(() => {
            const data = { name: "John", age: 30 };
            callback(data);
        }, 3000);
    }

    document.getElementById('callback-output').innerText = "Data is being fetched with Callback...";
    fetchDataCallback(function(data) {
        document.getElementById('callback-output').innerText = `Callback Example: ${JSON.stringify(data)}`;
    });
}

function runPromiseExample() {
    function fetchDataPromise() {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const data = { name: "Jane", age: 25 };
                resolve(data);
            }, 3000);
        });
    }

    document.getElementById('promise-output').innerText = "Data is being fetched with Promise...";
    fetchDataPromise()
        .then(data => {
            document.getElementById('promise-output').innerText = `Promise Example: ${JSON.stringify(data)}`;
        })
        .catch(error => {
            document.getElementById('promise-output').innerText = error;
        });
}

async function runAsyncAwaitExample() {
    async function fetchDataAsync() {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const data = { name: "Alice", age: 35 };
                resolve(data);
            }, 3000);
        });
    }

    document.getElementById('async-await-output').innerText = "Data is being fetched with Async/Await...";
    try {
        const response = await fetchDataAsync();
        document.getElementById('async-await-output').innerText = `Async/Await Example: ${JSON.stringify(response)}`;
    } catch (error) {
        document.getElementById('async-await-output').innerText = error;
    }
}

function runPromiseAllExample() {
    function fetchMultipleData() {
        const promise1 = new Promise((resolve) => {
            setTimeout(() => {
                resolve("Data from Promise 1");
            }, 1000);
        });

        const promise2 = new Promise((resolve) => {
            setTimeout(() => {
                resolve("Data from Promise 2");
            }, 2000);
        });

        const promise3 = new Promise((resolve) => {
            setTimeout(() => {
                resolve("Data from Promise 3");
            }, 3000);
        });

        return Promise.all([promise1, promise2, promise3]);
    }

    document.getElementById('promise-all-output').innerText = "Data is being fetched with Promise.all...";
    fetchMultipleData()
        .then(values => {
            document.getElementById('promise-all-output').innerText = `Promise.all Example: ${values}`;
        })
        .catch(error => {
            document.getElementById('promise-all-output').innerText = error;
        });
}

function checkAnswer(concept, answer) {
    const correctAnswers = {
        callback: "A function that is passed as an argument to another function",
        promise: "A built-in JavaScript object to handle asynchronous operations",
        asyncAwait: "Provides a more readable way to handle asynchronous code",
        promiseAll: "Executes multiple promises in parallel and waits for all to complete"
    };

    const feedbackElement = document.getElementById(`${concept}-feedback`);
    if (correctAnswers[concept] === answer) {
        feedbackElement.innerText = "Correct!";
        feedbackElement.style.backgroundColor = "#c8e6c9";
    } else {
        feedbackElement.innerText = "Incorrect. Try again!";
        feedbackElement.style.backgroundColor = "#ffcdd2";
    }
}
